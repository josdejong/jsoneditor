#!/bin/sh

package="jsoneditoronline.zip"
files="index.html jsoneditor.js jsoneditor.css img LICENSE NOTICE"

rm $package

# create zip file
zip -r $package $files
