/**
/**
 * @file jsoneditor.js
 * 
 * @brief 
 * JsonEditor is an editor to display and edit JSON data in a tree-like
 * editor. 
 * 
 * @license
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy 
 * of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 *
 * Copyright © 2011 Jos de Jong
 *
 * @author 	Jos de Jong, <wjosdejong@gmail.com>
 * @date	  2011-10-28
 */


// Internet Explorer 8 and older does not support Array.indexOf, 
// so we define it here in that case
// http://soledadpenades.com/2007/05/17/arrayindexof-in-internet-explorer/
if(!Array.prototype.indexOf) {
  Array.prototype.indexOf = function(obj){
    for(var i = 0; i < this.length; i++){
      if(this[i] == obj){
        return i;
      }
    }
    return -1;
  }
}


/**
 * JSONEditor
 * @param {HTML DOM} container    Container element
 * @param {Object or Array} json  JSON object
 */ 
JSONEditor = function (container, json) {
  // check availability of JSON parser (not available in IE7 and older)
  if (!JSON) {
    throw('Your browser does not support JSON. \n' +
      'Please install a decent, modern browser on your computer.');
  }

  if (!container) {
    throw 'No container element provided.';
  }
  this.container = container;

  this.set(json || {});
}

/**
 * Redraw the containts, resize the elements
 */ 
JSONEditor.prototype.redraw = function () {
  if (!this.frame) {
    return;
  }
  
  this.width = this.container.clientWidth;
  this.height = this.container.clientHeight;
  
  this.headerHeight = this.tableHeader.clientHeight;

  var actionsWidth = 133;
  
  this.frame.style.width = this.width - 2 + 'px';
  this.frame.style.height = this.height - 2 + 'px';

  var colWidth = (this.width - actionsWidth) / 2;
  this.tableHeader.style.width = this.width - 2 + 'px';
  this.tableContent.style.width = this.width - 2 + 'px';
  this.colgroupHeader.childNodes[0].width = colWidth + 'px';
  this.colgroupHeader.childNodes[1].width = colWidth + 'px';
  this.colgroupContent.childNodes[0].width = colWidth + 'px';
  this.colgroupContent.childNodes[1].width = colWidth + 'px';
  this.content.style.height = (this.height - this.headerHeight - 3) + 'px';
  this.content.style.width = this.width - 2 + 'px';
}

/**
 * Set JSON object in editor
 * @param {Object} json
 */ 
JSONEditor.prototype.set = function (json) {
  this.container.innerHTML = '';
  
  this.frame = document.createElement('div');
  this.frame.className = 'jsoneditor-frame';
  this.container.appendChild(this.frame);
  
  this._createHeader();
  this._createTable();

  this.structure = this._parse(undefined, json);
  
  this.redraw();
}

/**
 * Create header of the main table
 */ 
JSONEditor.prototype._createHeader = function () {
  this.tableHeader = document.createElement('table');
  this.tableHeader.className = 'jsoneditor-table';

  this.colgroupHeader = document.createElement('colgroup');
  var col = document.createElement('col');
  col.width = "200px";
  this.colgroupHeader.appendChild(col);
  var col = document.createElement('col');
  col.width = "200px";
  this.colgroupHeader.appendChild(col);
  var col = document.createElement('col');
  col.width = "133px";
  this.colgroupHeader.appendChild(col);
  this.tableHeader.appendChild(this.colgroupHeader);
  
  this.tbodyHeader = document.createElement('tbody');
  this.tableHeader.appendChild(this.tbodyHeader);
  
  var tr, th;  
  tr = document.createElement('tr');
  th = document.createElement('th');
  th.className = 'jsoneditor-th'; 
  th.appendChild(document.createTextNode('Field'));
  tr.appendChild(th);
  th = document.createElement('th');
  th.className = 'jsoneditor-th'; 
  th.appendChild(document.createTextNode('Value'));
  tr.appendChild(th);
  th = document.createElement('th');
  th.className = 'jsoneditor-th'; 
  th.appendChild(document.createTextNode('Edit'));
  tr.appendChild(th);
  this.tbodyHeader.appendChild(tr);
  
  this.frame.appendChild(this.tableHeader);
}

/**
 * Create main table
 */ 
JSONEditor.prototype._createTable = function () {
  var col;
  
  this.content = document.createElement('div');
  this.content.className = 'jsoneditor-content';
  this.frame.appendChild(this.content);
  
  this.tableContent = document.createElement('table');
  this.tableContent.className = 'jsoneditor-table';

  this.colgroupContent = document.createElement('colgroup');
  col = document.createElement('col');
  //col.width = "200px";
  this.colgroupContent.appendChild(col);
  col = document.createElement('col');
  //col.width = "200px";
  this.colgroupContent.appendChild(col);
  col = document.createElement('col');
  col.width = "50px";
  this.colgroupContent.appendChild(col);
  col = document.createElement('col');
  col.width = "20px";
  this.colgroupContent.appendChild(col);
  col = document.createElement('col');
  col.width = "40px";
  this.colgroupContent.appendChild(col);
  this.tableContent.appendChild(this.colgroupContent);

  this.tbody = document.createElement('tbody');
  this.tableContent.appendChild(this.tbody);
  
  this.content.appendChild(this.tableContent);
}


/**
 * Create a row for the table
 * @param {Array} fields    An array with HTML dom fields to be inserted
 *                          in the fields of the row
 * @param {HTML DOM} tr     The TR element to be added to the table
 */ 
JSONEditor.prototype._createRow = function (fields) {
  var tr = document.createElement('tr');
  tr.className = "jsoneditor-tr";

  for (var i = 0, iMax = fields.length; i < iMax; i++) {
    var td = document.createElement('td');
    var field = fields[i];
    td.className = 'jsoneditor-td'; 
    tr.appendChild(td);
    
    if (field) {
      td.appendChild(field);
    }
    
    // TODO: this is not so neat solution to give the edit buttons
    // another background color...
    if (i > 1) {
      td.className += ' jsoneditor-td-edit';
    }
  }
  
  return tr;
}

/**
 * Create an editable value
 * @param {JSON} value
 */ 
JSONEditor.prototype._createValue = function (structure) {
  var value = structure.value,
    domValue;
  
  if (value instanceof Array) {
    domValue = document.createElement('div');
    //domValue.className = 'jsoneditor-value jsoneditor-readonly';         // TODO: cleanup
    domValue.className = 'jsoneditor-readonly';    
    domValue.innerHTML = '[...]';
  }
  else if (value instanceof Object) {
    domValue = document.createElement('div');
    //domValue.className = 'jsoneditor-value jsoneditor-readonly';     // TODO: cleanup
    domValue.className = 'jsoneditor-readonly';    
    domValue.innerHTML = '{...}';
  }
  else if (typeof(value) == 'string') {
    domValue = document.createElement('div');
    domValue.contentEditable = 'true';
    domValue.className = 'jsoneditor-value';    
    this._setInnerText(domValue, value);
  }
  else {
    domValue = document.createElement('div');
    domValue.contentEditable = 'true';
    domValue.className = 'jsoneditor-value';    
    this._setInnerText(domValue, JSON.stringify(value));
  }

  structure.dom.value = domValue;
}

/**
 * Create an editable field
 * @param {Object} structure
 */ 
JSONEditor.prototype._createField = function (structure) {
  var parent = structure.parent,
    field = structure.field,
    editable = parent ? (parent.type != 'array') : false;

  if (parent == undefined && field == undefined) {
    if (structure.type == 'array' || structure.type == 'object') {
      field = structure.type;
    }
    else {
      field = 'field';
    }
  }
  if (field == undefined) {
    field = '';
  }
  
  var domField = document.createElement('div');
  domField.innerHTML = field;
  if (editable == true) {
    domField.contentEditable = 'true';
    domField.className = 'jsoneditor-field';
  }
  else {
    //domField.className = 'jsoneditor-field jsoneditor-readonly';  // TODO: cleanup
    domField.className = 'jsoneditor-readonly';
  }
  structure.dom.field = domField;
}

/**
 * Create a tree element
 * @param {Object} structure
 * @param {HTML DOM} domField
 */ 
JSONEditor.prototype._createTree = function (structure) {
  var editor = this;
  var domField = structure.dom.field;
  var domTree = document.createElement('table');
  var tbody = document.createElement('tbody');
  domTree.style.borderCollapse = 'collapse';
  domTree.appendChild(tbody);
  var tr = document.createElement('tr');
  tbody.appendChild(tr);
  
  var td = document.createElement('td');
  td.className = 'jsoneditor-td-tree';
  tr.appendChild(td);

  var buttonExpand = document.createElement('button');
  if (structure.type != 'array' && structure.type != 'object') {
    buttonExpand.className = 'jsoneditor-invisible';
  }
  else {
    buttonExpand.className = structure.collapsed ? 'jsoneditor-collapsed' : 'jsoneditor-expanded';
    
    buttonExpand.onclick = function (event) {
      structure.collapsed = !structure.collapsed;
      buttonExpand.className = structure.collapsed ? 'jsoneditor-collapsed' : 'jsoneditor-expanded';
      if (structure.collapsed) {
        editor._hide(structure);
      }
      else {
        editor._show(structure);
      }
    }    
  }
  td.style.paddingLeft = structure.level * 16 + 'px';  
  td.appendChild(buttonExpand);
  
  var td = document.createElement('td');
  td.className = 'jsoneditor-td-tree';
  tr.appendChild(td);
  td.appendChild(domField);
  
  structure.dom.buttonExpand = buttonExpand;
  structure.dom.tree = domTree;
}

/**
 * Recursively make all childs of the structure visible
 */ 
JSONEditor.prototype._show = function (structure) {
  var childs = structure.childs;
  for (var i = 0, iMax = childs.length; i < iMax; i++) {
    var child = childs[i];
    child.dom.row.style.display = '';
    if (!child.collapsed) {
      this._show(child);
    }
  }
}

/**
 * Recursively make all childs of the structure invisible
 */ 
JSONEditor.prototype._hide = function (structure) {
  var childs = structure.childs;
  for (var i = 0, iMax = childs.length; i < iMax; i++) {
    var child = childs[i];
    child.dom.row.style.display = 'none';
    this._hide(child);
  }
}


/**
 * Create an editable type
 * @param {Object} structure
 */ 
JSONEditor.prototype._createType = function (structure) {
  var type = structure.type;
  var domType = document.createElement('select');
  domType.className = 'jsoneditor-type';
  domType.title = 'Field type. When \"auto\" is selected, the type is automatically determined.';

  var options = ['array', 'auto', 'object', 'string'];
  for (var i in options) {
    var optionDom = document.createElement('option');
    optionDom.value = options[i];
    optionDom.innerHTML = options[i];
    domType.appendChild(optionDom);
  }
  domType.value = structure.type;

  var me = this;
  domType.onchange = function (event) {
    var newType = domType.value;
    me._change(structure, newType);
  }

  structure.dom.type = domType;
}

/**
 * Create an append button. Returns undefined when the structure cannot
 * have an append button
 * @param {String} type
 * @return {HTML DOM} buttonAppend
 */ 
JSONEditor.prototype._createAppendButton = function (structure) {
  if (structure.type == 'object' || structure.type == 'array') {
    var buttonAppend = document.createElement('button');
    buttonAppend.className = 'jsoneditor-append';
    buttonAppend.title = 'Append a field';
    
    var me = this;
    buttonAppend.onclick = function (event) {
      me._append(structure);
    }
    
    structure.dom.buttonAppend = buttonAppend;
  }
}


/**
 * Create a remove button. Returns undefined when the structure cannot
 * be removed
 * @param {String} type
 * @return {HTML DOM} removeButton
 */ 
JSONEditor.prototype._createRemoveButton = function (structure) {
  var parent = structure.parent;
  if (parent) {
    var buttonRemove = document.createElement('button');
    buttonRemove.className = 'jsoneditor-remove';
    buttonRemove.title = 'Remove field (including all its childs)';
    
    var me = this;
    buttonRemove.onclick = function (event) {
      me._remove(structure);
    }
    
    structure.dom.buttonRemove = buttonRemove;
  }
}

/**
 * Create the THML dom for a structure
 * @param {Object} structure
 * @return {Object} 
 */ 
JSONEditor.prototype._createDom = function (structure) {
  var parent = structure.parent;
  structure.dom = {};

  this._createField(structure);
  this._createValue(structure);
  this._createType(structure);
  this._createTree(structure);
  this._createAppendButton(structure);
  this._createRemoveButton(structure);
  
  var dom = structure.dom;
  dom.row = this._createRow([
    dom.tree, 
    dom.value, 
    dom.type, 
    dom.buttonAppend, 
    dom.buttonRemove
  ]);
}


/**
 * recursively remove a structure and its childs
 * @param {Object} structure
 */ 
JSONEditor.prototype._remove = function (structure) {
  // remove the childs
  if (structure.type == 'array' || structure.type == 'object') {
    var childs = structure.childs;
    while (childs.length) {
      this._remove(childs[0]);
    }
  }
  
  // remove the html dom
  this.tbody.removeChild(structure.dom.row);
    
  var parent = structure.parent;
  if (parent) {
    // remove the structure itself
    var index = parent.childs.indexOf(structure);
    if (index != -1) {
      parent.childs.splice(index, 1);
    }
    
    // update indexes (only in case of an array)
    this._updateIndexes(parent);
    this._updateStatus(parent);
  }
  else if (structure = this.structure) {
    this.structure = undefined;
  }
}

/**
 * Update the indexes of the given structure. 
 * Only applicable when structure is an array
 */ 
JSONEditor.prototype._updateIndexes = function (structure) {
  if (structure && structure.type == 'array') {
    var childs = structure.childs;
    for (var i = 0, iMax = childs.length; i < iMax; i++) {
      childs[i].dom.field.innerHTML = i;
    }
  }
}

/**
 * Update the title of the given structure. 
 * Only applicable when structure is an array or object
 */ 
JSONEditor.prototype._updateStatus = function (structure) {
  if (structure && structure.type == 'array' || structure.type == 'object') {
    var type = structure.type,
      name = structure.field ? ('\"' + structure.field + '\"') : '',
      count = structure.childs ? structure.childs.length : 0;
    
    structure.dom.value.title = type + name + '  has ' + count + ' childs';
  }
}


/**
 * recursively retrieve the last child of a structure
 * @param {Object} structure
 * @return {Object} structure of the last child, or undefined if no childs
 */ 
JSONEditor.prototype._getLastChild = function (structure) {
  var count = structure.childs.length;
  var lastChild = structure.childs[count - 1];
  
  if (lastChild) {
    if (lastChild.childs.length) {
      return this._getLastChild(lastChild);
    }
    else {
      return lastChild;
    }
  }
  
  return undefined;
}


/**
 * append a field to the given structure
 * @param {Object} structure
 */ 
JSONEditor.prototype._append = function (structure) {
  if (structure.type == 'array' || structure.type == 'object') {
    if (structure.collapsed) {
      structure.collapsed = false;
      structure.dom.buttonExpand.className = 'jsoneditor-expanded';
      this._show(structure);
    }
    
    var lastChild = this._getLastChild(structure);
    var nextRow = lastChild ? lastChild.dom.row.nextSibling : structure.dom.row.nextSibling;
    
    var newStructure = {
      'field': (structure.type == 'object') ? 'field' : String(structure.childs.length),
      'value': 'value',
      'type': 'auto',
      'parent': structure,
      'childs': [],
      'level': structure.level + 1,
      'collapsed': false
    };
    structure.childs.push(newStructure);
    this._createDom(newStructure);

    if (nextRow) {
      this.tbody.insertBefore(newStructure.dom.row, nextRow);
    } 
    else {
      this.tbody.appendChild(newStructure.dom.row);
    }

    newStructure.dom.value.focus();
  }
}

/**
 * change an existing structure to a new type
 * @param {Object} structure
 */ 
JSONEditor.prototype._change = function (structure, newType) {
  var oldType = structure.type;

  if ((newType == 'string' || newType == 'auto') && 
      (oldType == 'string' || oldType == 'auto')) {
    // this is an easy change
    structure.type = newType;
  }
  else {
    // change from array to object, or from string/auto to object/array

    // get the link to the next row in the table, new structure must 
    // be inserted before the next field
    var parent = structure.parent;
    var level = parent ? (parent.level + 1) : 0;
    var index = parent ? parent.childs.indexOf(structure) : -1;
    var lastChild = this._getLastChild(structure);
    var nextRow = lastChild ? lastChild.dom.row.nextSibling : structure.dom.row.nextSibling;
    var field = structure.field;
    var value = (newType == 'object') ? {} : ((newType == 'array') ? [] : '');

    var newStructure = {
      'field': field,
      'value': value,
      'type': newType,
      'parent': parent,
      'childs': [],
      'level': level,
      'collapsed': true
    };
    this._createDom(newStructure);
    
    this._remove(structure);

    if (parent) {
      // there is a parent
      parent.childs.splice(index, 0, newStructure);

      this._updateIndexes(parent);
      this._updateStatus(parent);
    }
    else {
      // this is the root element
      this.structure = newStructure;
    }
    
    if (nextRow) {
      this.tbody.insertBefore(newStructure.dom.row, nextRow);
    } 
    else {
      this.tbody.appendChild(newStructure.dom.row);
    }
    
    if (newType == 'auto' || newType == 'string') {
      structure.dom.value.focus();    
    }
  }
  
  
  if (structure.type == 'array' || structure.type == 'object') {
    if (structure.collapsed) {
      structure.collapsed = false;
      structure.dom.buttonExpand.className = 'jsoneditor-expanded';
      this._show(structure);
    }
    
    var newStructure = {
      'field': (structure.type == 'object') ? 'field' : String(structure.childs.length),
      'value': 'value',
      'type': 'auto',
      'parent': structure,
      'childs': [],
      'level': structure.level + 1,
      'collapsed': false
    };
    structure.childs.push(newStructure);
    this._createDom(newStructure);


    newStructure.dom.value.focus();
  }
}


/**
 * get the type of a value
 * @param {any type} value
 * @return {String} type   Can be 'object', 'array', 'string', 'auto'
 */ 
JSONEditor.prototype._getType = function(value) {
  if (value instanceof Array) {
    return 'array';
  }
  if (value instanceof Object) {
    return 'object';
  }  
  if (typeof(value) == 'string' && typeof(this._stringCast(value)) != 'string') {
    return 'string';
  }
  
  return 'auto';
}

/**
 * cast contents of a string to the correct type. This can be a string, 
 * a number, a boolean, etc
 * @param {String} str
 * @return {String} type
 */ 
JSONEditor.prototype._stringCast = function(str) {
  var lower = str.toLowerCase(),
    num = Number(str),       // will nicely fail with '123ab'
    float = parseFloat(str); // will nicely fail with '  '

  if (str == '') {
    return '';
  }
  else if (lower == 'null') {
    return null;
  }
  else if (lower == 'true') {
    return true;
  }
  else if (lower == 'false') {
    return false;
  }
  else if (!isNaN(num) && !isNaN(float)) {
    return num;
  }
  else {
    return str;
  }
}

/**
 * get the innertext of an HTML element (for example a div element)
 * @param {HTML DOM} element
 * @return {String} innerText
 */ 
JSONEditor.prototype._getInnerText = function (element) {
  if (element.innerText) {
    return element.innerText;
  }
  
  // text node
  if (element.nodeValue) {
    return element.nodeValue;
  }
        
  // divs or other HTML elements
  if (element.hasChildNodes()) {
    var childNodes = element.childNodes;
    var innerText = "";

    for (var i = 0, iMax = childNodes.length; i < iMax; i++) {
      var child = childNodes[i];
      innerText += this._getInnerText(child);

      // TODO: check if this rule for adding \n is correct in all cases
      if (child.nodeName === 'DIV' && 
          innerText[innerText.length-1] !== '\n') {
        innerText += '\n';  
      }
    }

    return innerText;
  }

  // br
  if (element.nodeName === 'BR') {
    return '\n';
  }
  
  // unknown
  return '';
}

/**
 * set the innertext of an HTML element (for example a div element)
 * @param {HTML DOM} element
 * @param {String} innerText
 */ 
JSONEditor.prototype._setInnerText = function (element, innerText) {
  if (element.innerText) {
    element.innerText = innerText;
  }

  var innerHTML = innerText.replace(/\n/g, '<br>');
  element.innerHTML = innerHTML;
}

/**
 * recursively parse json data into a table structure
 * @param {String} field
 * @param {Object or Array} value   Json structure with value
 * @param {Ojbect} parent object
 * @param {Number} level     indentation level
 * @return {Object} structure
 */ 
JSONEditor.prototype._parse = function (field, value, parent, level) {
  var level = level || 0;
  var structure = {
    'field': field,
    'value': value,
    'type': this._getType(value),
    'parent': parent,
    'childs': [],
    'level': level,
    'collapsed': false
  };

  this._createDom(structure);
  this.tbody.appendChild(structure.dom.row);
  var dom = structure.dom;
  
  if (structure.type == 'array') {
    for (var i = 0, iMax = value.length; i < iMax; i++) {
      var child = this._parse(i, value[i], structure, level+1);
      structure.childs.push(child);
    }
  }
  else if (structure.type == 'object') {
    for (var field in value) {
      if (value.hasOwnProperty(field)) {
        var child = this._parse(field, value[field], structure, level+1);
        structure.childs.push(child);
      }
    }
  }
  // null?
  // regex?

  this._updateStatus(structure);
  
  return structure;
}

/**
 * recursively retrieve the current JSON data from the data structure
 * @param {Object} structure
 * @return {JSON} data
 */ 
JSONEditor.prototype._retrieve = function (structure) {
  var value;
  if (structure.type == 'array') {
    value = [];
    var childs = structure.childs;
    for (var i = 0, iMax = childs.length; i < iMax; i++) {
      value.push(this._retrieve(childs[i]));
    }
  }
  else if (structure.type == 'object') {
    value = {};
    var childs = structure.childs;
    for (var i = 0, iMax = childs.length; i < iMax; i++) {
      var field = this._escapeText(this._getInnerText(childs[i].dom.field));
      value[field] = this._retrieve(childs[i]);
    }
  }
  else if (structure.type == 'string') {
    value = structure.dom.value.innerHTML;
  }
  else {
    var innerText = this._escapeText(this._getInnerText(structure.dom.value));
    value = this._stringCast(innerText);
  }
  
  return value;
}

/**
 * replace all return characters with escaped characters
 * @param {String} text
 * @return {String} escaped text
 */ 
JSONEditor.prototype._escapeText = function (text) {
  if (text.charAt(text.length - 1) == '\n') {
    // remove last return character
    text = text.substring(0, text.length - 1);  
  }
  
  return text.replace(/\n/g, '\\n');
}


/**
 * Get JSON object from editor
 * @return {Object} json
 */ 
JSONEditor.prototype.get = function () {
  if (this.structure) {
    return this._retrieve(this.structure);
  }
  else {
    return {};
  }
}


JSONFormatter = function (container) {
  // check availability of JSON parser (not available in IE7 and older)
  if (!JSON) {
    throw('Your browser does not support JSON. \n' +
      'Please install a decent, modern browser on your computer.');
  }
  
  this.container = container;

  this.width = container.clientWidth;
  this.height = container.clientHeight;

  this.frame = document.createElement('div');
  this.frame.className = "jsoneditor-frame";

  this.head = document.createElement('table');
  this.head.className = 'jsonformatter-table'; 
  var tbody = document.createElement('tbody');
  this.head.appendChild(tbody);
  this.frame.appendChild(this.head);

  var tr = document.createElement('tr');
  var th = document.createElement('th');
  th.className = 'jsoneditor-th'; 
  var buttonFormat = document.createElement('button');
  buttonFormat.innerHTML = 'Format';
  buttonFormat.title = 'Format JSON data, with proper indentation and line feeds';
  buttonFormat.className = 'jsoneditor-button';
  th.appendChild(buttonFormat);
  tr.appendChild(th);
  tbody.appendChild(tr);

  var buttonMinify = document.createElement('button');
  buttonMinify.innerHTML = 'Minify';
  buttonMinify.title = 'Minify JSON data, remove all whitespaces';
  buttonMinify.className = 'jsoneditor-button';
  th.appendChild(buttonMinify);
  tr.appendChild(th);
  tbody.appendChild(tr);

  this.textarea = document.createElement('textarea');
  this.textarea.className = "jsonformatter-textarea";
  //td.appendChild(this.textarea);
  this.frame.appendChild(this.textarea);
  //td.style.padding = '0px';
  
  /*
  var test = document.createElement('div');
  test.style.height = '300px';
  test.style.backgroundColor = 'green';
  this.frame.appendChild(test);
  */
  
  var textarea = this.textarea;
  buttonFormat.onclick = function () {
    textarea.value = JSONFormatter.format(JSON.parse(textarea.value));
  };
  buttonMinify.onclick = function () {
    textarea.value = JSON.stringify(JSON.parse(textarea.value));
  };
  
  this.container.appendChild(this.frame);
  
  // resize the elements
  this.redraw();
}

/**
 * Redraw the JSONFormatter, adjust size to fit container
 */ 
JSONFormatter.prototype.redraw = function() {
  this.width = this.container.clientWidth;
  this.height = this.container.clientHeight;
  this.headHeight = this.head.clientHeight;


// TODO: cleanup here
this.frame.style.overflow = 'hidden';
  //this.head.style.height = '300px';

//this.container.style.overflow = 'hidden';
  this.frame.style.width = this.width - 2 + 'px';
  this.frame.style.height = this.height - 2 + 'px';
  
  //this.frame.style.border = '1px solid red';
  
  this.textarea.style.height = (this.height - this.headHeight - 3) + 'px';
  //this.textarea.style.height = 400 + 'px';
  this.textarea.style.width = '100%';
}

/**
 * Set json data in the formatter
 * @param {JSON} json
 */ 
JSONFormatter.prototype.set = function(json) {
  this.textarea.value = JSONFormatter.format(json);
}

/**
 * Get json data from the formatter
 * @return {JSON} json
 */ 
JSONFormatter.prototype.get = function() {
  return JSON.parse(this.textarea.value);
}

/**
 * Format a json object as string
 * Example usage: 
 *   JSONFormatter.format({"field1": "bla", "somevalues": [1, 2, 3]});
 * 
 * @param {Object} json    A json object
 * @param {Number} level   Indentation level. Optional
 * @return {String} string Formatted string
 */
JSONFormatter.format = function (json, level) {
  var tab = '  ';  // indentation of 2 spaces (you can change this)
  var str = '';
  var level = level || 0;

  var indent = '';
  for(var i = 0; i < level; i++) {
    indent += tab;
  }

  if (json instanceof Array) {
    str += '[';
    var first = true;
    for (var i = 0, iMax = json.length; i < iMax; i++) {
      if (first) {
        first = false;
      }
      else {
        str += ',';
      }
      str += '\n' + indent + tab;
      str += JSONFormatter.format(json[i], level + 1);
    }
    str += '\n' + indent;
    str += ']';
  }
  else if (json instanceof Object) {
    str += '{';
    var first = true;
    for (var i in json) {
      if (json.hasOwnProperty(i)) {
        if (first) {
          first = false;
        }
        else {
          str += ',';
        }
        str += '\n' + indent + tab;
        str += '"' + i + '": ';
        str += JSONFormatter.format(json[i], level + 1);
      }
    }
    str += '\n' + indent;
    str += '}';
  }
  else if (typeof(json) == 'string') {
    return '"' + json + '"';
  }
  else {
    return String(json);
  }
  
  return str;
}

