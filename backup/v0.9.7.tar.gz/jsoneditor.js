/**
 * @file jsoneditor.js
 * 
 * @brief 
 * JsonEditor is an editor to display and edit JSON data in a treeview. 
 * 
 * Supported browsers: Chrome, Firefox, Safari, Opera, Internet Explorer 8+ 
 * 
 * @license
 * Licensed under the Apache License, Version 2.0 (the "License"); you may not
 * use this file except in compliance with the License. You may obtain a copy 
 * of the License at
 * 
 * http://www.apache.org/licenses/LICENSE-2.0
 * 
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS, WITHOUT
 * WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied. See the
 * License for the specific language governing permissions and limitations under
 * the License.
 *
 * Copyright © 2011 Jos de Jong
 *
 * @author 	Jos de Jong, <wjosdejong@gmail.com>
 * @date	  2011-11-27
 */


// Internet Explorer 8 and older does not support Array.indexOf, 
// so we define it here in that case
// http://soledadpenades.com/2007/05/17/arrayindexof-in-internet-explorer/
if(!Array.prototype.indexOf) {
  Array.prototype.indexOf = function(obj){
    for(var i = 0; i < this.length; i++){
      if(this[i] == obj){
        return i;
      }
    }
    return -1;
  }
}

// define variable JSON, needed for correct error handling on IE7 and older
var JSON;

/**
 * JSONEditor
 * @param {HTML DOM} container    Container element
 * @param {Object or Array} json  JSON object
 */ 
JSONEditor = function (container, json) {
  // check availability of JSON parser (not available in IE7 and older)
  if (!JSON) {
    throw 'Your browser does not support JSON. \n\n' +
      'Use a decent, modern browser, please.';
  }

  if (!container) {
    throw 'No container element provided.';
  }
  this.container = container;

  this._preloadImages();

  this._createFrame();
  this._createTable();

  this.set(json || {});
}

/**
 * Preload images for the editor
 */ 
JSONEditor.prototype._preloadImages = function() {
  // TODO: test if the preloading works.
  var img = {};

  img.add_gray = new Image(); 
  img.add_gray.src = "img/add_gray.png";
  img.add_green = new Image(); 
  img.add_green.src = "img/add_green.png";

  img.delete_gray = new Image(); 
  img.delete_gray.src = "img/delete_gray.png";
  img.delete_red = new Image(); 
  img.delete_red.src = "img/delete_red.png";

  img.treeDownTriangleBlack = new Image(); 
  img.treeDownTriangleBlack.src = "img/treeDownTriangleBlack.png";
  img.treeRightTriangleBlack = new Image(); 
  img.treeRightTriangleBlack.src = "img/treeRightTriangleBlack.png";

  this.img = img; // TODO: is this needed?
}

/**
 * Set JSON object in editor
 * @param {Object} json
 */ 
JSONEditor.prototype.set = function (json) {
  this.frame.removeChild(this.table);  // Take the table offline
  
  if (this.node) {
    // remove existing DOM
    this.node.remove();
  }
  
  this.node = new JSONEditor.Node({
    'value': json
  });
  this.node.append(this.table);

  // expand up to a certain maximum level by default
  var maxLevel = 0;  // TODO: make an option for the default expansion level
  this.node.expand(maxLevel);

  this.frame.appendChild(this.table);  // Put the table online again
}

/**
 * Expand all nodes
 */ 
JSONEditor.prototype.expandAll = function () {
  if (this.node) {
    this.frame.removeChild(this.table);  // Take the table offline
    this.node.expand();
    this.frame.appendChild(this.table);  // Put the table online again
  }
}

/**
 * Collapse all nodes
 */ 
JSONEditor.prototype.collapseAll = function () {
  if (this.node) {
    this.frame.removeChild(this.table);  // Take the table offline
    this.node.collapse();
    this.frame.appendChild(this.table);  // Put the table online again

  }
}

/**
 * Create a new Node
 * @param {Object} params   Can contain parameters: level, field, fieldEditable, 
 *                          value.
 */ 
JSONEditor.Node = function (params) {
  if(params && (params instanceof Object)) {
    this.parent = params.parent;
    this.setLevel(params.level);
    this.setField(params.field, params.fieldEditable);
    this.setValue(params.value);
  }
  else {
    this.parent = undefined;
    this.setLevel();
    this.setField();
    this.setValue();
  }

  this.expanded = false;
}

JSONEditor.Node.prototype.setField = function(field, fieldEditable) {
  this.field = field;
  this.fieldEditable = (fieldEditable == true);
}

JSONEditor.Node.prototype.getField = function() {
  this._getDomField();
  
  return this.field;
}

JSONEditor.Node.prototype.setValue = function(value) {
  // first clear current childs and DOM
  this.childs = undefined;
  this.remove();

  this.type = this._getType(value);
  if (this.type == 'array') {
    this.childs = [];
    var childLevel = this.level + 1;
    for (var i = 0, iMax = value.length; i < iMax; i++) {
      var child = new JSONEditor.Node({
        'parent': this, 
        'field': i, 
        'value': value[i], 
        'level': childLevel
      });
      this.childs.push(child);
    }
  }
  else if (this.type == 'object') {
    this.childs = [];
    var childLevel = this.level + 1;
    for (var childField in value) {
      if (value.hasOwnProperty(childField)) {
        var child = new JSONEditor.Node({
          'parent': this, 
          'field': childField,
          'fieldEditable': true ,
          'value': value[childField], 
          'level': childLevel
        });
        this.childs.push(child);
      }
    }
  }
  else {
    this.value = value;
  }
}

JSONEditor.Node.prototype.getValue = function() {
  this._getDomValue();
  
  if (this.type == 'array') {
    var arr = [];
    for (var i = 0, iMax = this.childs.length; i < iMax; i++) {
      arr.push(this.childs[i].getValue());
    }
    return arr;
  }
  else if (this.type == 'object') {
    var obj = {};
    for (var i = 0, iMax = this.childs.length; i < iMax; i++) {
      var child = this.childs[i];
      obj[child.getField()] = child.getValue();
    }
    return obj;
  }  
  else {
    return this.value;
  }
}

JSONEditor.Node.prototype.setLevel = function(level) {
  this.level = level || 0;
  
  // adjust the level for the childs
  if (this.childs) {
    var childLevel = this.level + 1;
    for (var i = 0, iMax = this.childs.length; i < iMax; i++) {
      this.childs[i].setLevel(childLevel);
    }
  }

  if (this.dom) {
    // TODO: redraw DOM
  }
}

JSONEditor.Node.prototype.getLevel = function() {
  return this.level;
}

/**
 * Insert the DOM of this Node before given table row
 * @param {HTML DOM TABLE element} table 
 * @param {HTML DOM TR element} tr 
 */ 
JSONEditor.Node.prototype.insertBefore = function(table, tr) {
  if (!this.dom) {
    var newTr = this._createDom();
    table.insertBefore(newTr, tr);
    
    if (this.expanded) {
      this.expand(this.level);
    }
  }
}

/**
 * Append the DOM of this Node to the given table
 * @param {HTML DOM TABLE element} table 
 */ 
JSONEditor.Node.prototype.append = function(table) {
  if (!this.dom) {
    var newTr = this._createDom();
    table.appendChild(newTr);

    if (this.expanded) {
      this.expand(this.level);
    } 
  }
}

/**
 * Remove the DOM of this Node from the table
 */ 
JSONEditor.Node.prototype.remove = function() {
  if (this.dom) {
    if (this.expanded && this.childs) {
      for (var i = 0, iMax = this.childs.length; i < iMax; i++) {
        this.childs[i].remove();
      }
    }

    this._getDomField();
    this._getDomValue();

    var tr = this.dom.tr;
    if (tr) {
      var parent = tr.parentNode;
      parent.removeChild(tr);
    }

    this.dom = undefined;
  }
}

/**
 * Expand this node and optionally its childs, until a maximum depth.
 * @param {Number} maxLevel   Optional maximum level. undefined by default. When
 *                            undefined, all childs will be expanded recursively
 */ 
JSONEditor.Node.prototype.expand = function(maxLevel) {
  if (!this.childs) {
    return;
  }

  this.expanded = true;
  if (this.dom && this.dom.buttonExpand) {
    this.dom.buttonExpand.className = 'jsoneditor-expanded';
  }

  var tr = this.dom ? this.dom.tr : undefined;
  if (tr) {
    var parent = tr.parentNode;
    var nextTr = tr.nextSibling;
    
    if (nextTr) {
      for (var i = 0, iMax = this.childs.length; i < iMax; i++) {
        var child = this.childs[i];
        child.insertBefore(parent, nextTr);
      }
    }
    else {
      for (var i = 0, iMax = this.childs.length; i < iMax; i++) {
        var child = this.childs[i];
        child.append(parent);
      }
    }
  }  
  
  if (maxLevel == undefined || this.level < maxLevel) {
    for (var i = 0, iMax = this.childs.length; i < iMax; i++) {
      this.childs[i].expand(maxLevel);
    }
  }
}

/**
 * Collapse this node and optionally its childs, until a maximum depth.
 * @param {Number} maxLevel   Optional maximum level. undefined by default. When
 *                            undefined, all childs will be collapsed recursively
 */ 
JSONEditor.Node.prototype.collapse = function(maxLevel) {
  if (!this.childs) {
    return;
  }
  
  this.expanded = false;
  
  if (this.dom && this.dom.buttonExpand) {
    this.dom.buttonExpand.className = 'jsoneditor-collapsed';
  }

  for (var i = 0, iMax = this.childs.length; i < iMax; i++) {
    this.childs[i].remove();
  }
  
  // collapse childs in case of maxLevel
  if (maxLevel == undefined || this.level < maxLevel) {
    for (var i = 0, iMax = this.childs.length; i < iMax; i++) {
      this.childs[i].collapse(maxLevel);
    }
  }
}

/**
 * Add a new child to the node. 
 * Only applicable when Node value is of type array or object
 */ 
JSONEditor.Node.prototype._addChild = function() {
  if (this.type == 'array' || this.type == 'object') {
    if (!this.expanded) {
      this.expand(this.level);
    }
    
    var lastTr = this._getLastDomTr();
    
    var child = new JSONEditor.Node({
      'parent': this,
      'level': this.level + 1, 
      'field': (this.type == 'object') ? 'field' : String(this.childs.length),
      'fieldEditable': (this.type == 'object'),
      'value': 'value'
    });
    this.childs.push(child);

    if (lastTr) {
      var parent = lastTr.parentNode;
      var nextTr = lastTr.nextSibling;
      
      if (nextTr) {
        child.insertBefore(parent, nextTr);
      }
      else {
        child.append(parent);
      }
      
      child.dom.value.focus();
    }
    
    this._updateDomStatus();
  }
}

/**
 * Remove a child from the node. 
 * Only applicable when Node value is of type array or object
 * @param {JSONEditor.Node} child node to be removed;
 */ 
JSONEditor.Node.prototype._removeChild = function(childNode) {
  if (this.childs) {
    var index = this.childs.indexOf(childNode);
  
    if (index != -1) {
      // remove the DOM
      childNode.remove();

      this.childs.splice(index, 1);
      
      // in case of array: update the lower down indexes
      if (this.type == 'array' && this.dom) {
        for (var i = index, iMax = this.childs.length; i < iMax; i++) {
          this.childs[i].dom.field.innerHTML = i;
        }
      }

      this._updateDomStatus();
    }
  }
}


/**
 * change the type of the value of this Node
 * @param {String} newType
 */ 
JSONEditor.Node.prototype._changeType = function ( newType) {
  var oldType = this.type;

  if ((newType == 'string' || newType == 'auto') && 
      (oldType == 'string' || oldType == 'auto')) {
    // this is an easy change
    this.type = newType;
  }
  else {
    // change from array to object, or from string/auto to object/array

    var table = this.dom ? this.dom.tr.parentNode : undefined;
    var lastTr = this._getLastDomTr();
    var nextTr = lastTr ? lastTr.nextSibling : undefined;

    // remove DOM of current field
    this.remove();
    
    // adjust the field and the value
    this.type = newType;
    this.expanded = false;

    // adjust childs
    if (newType == 'object') {
      this.value = {};
      this.childs = [];
    }
    else if (newType == 'array') {
      this.value = [];
      this.childs = [];
    }
    else {
      this.value = '';
      this.childs = undefined;
    }

    // create new DOM
    if (table) {
      if (nextTr) {
        this.insertBefore(table, nextTr);
      }
      else {
        this.append(table);
      }
    }
    
    if (newType == 'auto' || newType == 'string') {
      this.dom.value.focus();    
    }
  }
}



/**
 * recursively retrieve the last DOM table row of a node
 * @return {HTML TR} last TR element of its childs
 */ 
JSONEditor.Node.prototype._getLastDomTr = function () {
  if (this.childs && this.expanded) {
    var count = this.childs.length;
    var lastChild = this.childs[count - 1];
    
    if (lastChild) {
      return lastChild._getLastDomTr();
    }
  }
  
  if (this.dom && this.dom.tr) {
    return this.dom.tr;
  }
  
  return undefined;
}

/**
 * Retrieve value from DOM
 */ 
JSONEditor.Node.prototype._getDomValue = function() {
  if (this.dom && this.type != 'array' && this.type != 'object') {
    // retrieve the value
    if (this.type == 'string') {
      this.value = this._removeReturn(this._getInnerText(this.dom.value));
    }
    else {
      var innerText = this._removeReturn(this._getInnerText(this.dom.value));
      this.value = this._stringCast(innerText);
    }
  }
}

/**
 * Retrieve field from DOM
 */ 
JSONEditor.Node.prototype._getDomField = function() {
  if (this.dom && this.type != 'array' && this.type != 'object') {
    // retrieve the field
    if (this.field) {
      this.field = this._removeReturn(this._getInnerText(this.dom.field));
    }
  }
}

/**
 * Create the DOM for this Node
 */ 
JSONEditor.Node.prototype._createDom = function() {
  if (this.dom) {
    return;
  }
  
  var dom = {};
  
  // create row
  dom.tr = document.createElement('tr');
  
  // create tree and field
  dom.tdField = document.createElement('td');
  dom.tdField.className = 'jsoneditor-td'; 
  dom.tr.appendChild(dom.tdField);
  dom.field = this._createDomField();
  var fields = this._createDomTree(dom.field);
  dom.tree = fields.tree;
  dom.buttonExpand = fields.buttonExpand;
  dom.tdField.appendChild(dom.tree);

  // create value
  dom.tdValue = document.createElement('td');
  dom.tdValue.className = 'jsoneditor-td'; 
  dom.tr.appendChild(dom.tdValue);
  dom.value = this._createDomValue();
  dom.tdValue.appendChild(dom.value);
  
  // create type select box
  dom.tdType = document.createElement('td');
  dom.tdType.className = 'jsoneditor-td jsoneditor-td-edit'; 
  dom.tr.appendChild(dom.tdType);
  dom.type = this._createDomType();
  dom.tdType.appendChild(dom.type);

  // create append button
  dom.tdAppend = document.createElement('td');
  dom.tdAppend.className = 'jsoneditor-td jsoneditor-td-edit'; 
  dom.tr.appendChild(dom.tdAppend);
  dom.append = this._createDomAppendButton();
  if (dom.append) {
    dom.tdAppend.appendChild(dom.append);
  }
  
  // create remove button
  dom.tdRemove = document.createElement('td');
  dom.tdRemove.className = 'jsoneditor-td jsoneditor-td-edit'; 
  dom.tr.appendChild(dom.tdRemove);
  dom.remove = this._createDomRemoveButton();
  if (dom.remove) {
    dom.tdRemove.appendChild(dom.remove);
  }
  
  this.dom = dom;

  this._updateDomStatus();
  
  return dom.tr;
}

/**
 * Create an editable field
 * @param {Object} structure
 */ 
JSONEditor.Node.prototype._createDomField = function () {
  var field = this.field;
  if (field == undefined) {
    if (this.type == 'array' || this.type == 'object') {
      field = this.type;
    }
    else {
      field = 'field';
    }
  }
  
  var domField = document.createElement('div');
  domField.innerHTML = field;
  if (this.fieldEditable == true) {
    domField.contentEditable = 'true';
    domField.className = 'jsoneditor-field';
  }
  else {
    domField.className = 'jsoneditor-readonly';
  }
  
  return domField;
}

/**
 * Update the title of the given structure. 
 * Only applicable when structure is an array or object
 */ 
JSONEditor.Node.prototype._updateDomStatus = function (structure) {
  if (this.dom) {
    var count = this.childs ? this.childs.length : 0;
    if (this.type == 'array') {
      this.dom.value.innerHTML = '[' + count + ']';
    }
    else if (this.type == 'object') {
      this.dom.value.innerHTML = '{' + count + '}';
    } 
    this.dom.value.title = this.type + ' containing ' + count + ' items';
  }
}

/**
 * Create an editable value
 * @param {JSON} value
 */ 
JSONEditor.Node.prototype._createDomValue = function () {
  var domValue;
  
  if (this.type == 'array') {
    domValue = document.createElement('div');
    domValue.className = 'jsoneditor-readonly';    
    domValue.innerHTML = '[...]';
  }
  else if (this.type == 'object') {
    domValue = document.createElement('div');
    domValue.className = 'jsoneditor-readonly';    
    domValue.innerHTML = '{...}';
  }
  else if (this.type == 'string') {
    domValue = document.createElement('div');
    domValue.contentEditable = 'true';
    domValue.className = 'jsoneditor-value';    
    this._setInnerText(domValue, String(this.value));
  }
  else {
    domValue = document.createElement('div');
    domValue.contentEditable = 'true';
    domValue.className = 'jsoneditor-value';    
    this._setInnerText(domValue, String(this.value));
  }

  return domValue;
}

/**
 * Create a DOM tree element, containing the expand/collapse button
 * @param {Object} fields   Object containing tree and buttonExpand DOM elements
 */ 
JSONEditor.Node.prototype._createDomTree = function (domField) {
  // TODO: replace the table by a div. will be faster for rendering I think

  var domTree = document.createElement('table');
  var tbody = document.createElement('tbody');
  domTree.style.borderCollapse = 'collapse';
  domTree.appendChild(tbody);
  var tr = document.createElement('tr');
  tbody.appendChild(tr);
  
  // create expand button
  var td = document.createElement('td');
  td.className = 'jsoneditor-td-tree';
  tr.appendChild(td);
  var buttonExpand = document.createElement('button');
  td.appendChild(buttonExpand);
  td.style.paddingLeft = this.level * 16 + 'px';
  if (this.type == 'array' || this.type == 'object') {
    buttonExpand.className = this.expanded ? 'jsoneditor-expanded' : 'jsoneditor-collapsed';

    var me = this;
    buttonExpand.onclick = function (event) {
      me.expanded = !me.expanded;
      if (me.expanded) {
        me.expand(me.level);
      }
      else {
        me.collapse(me.level);
      }
    }
  }
  else {
    buttonExpand.className = 'jsoneditor-invisible';
  }
  
  var td = document.createElement('td');
  td.className = 'jsoneditor-td-tree';
  tr.appendChild(td);
  td.appendChild(domField);
  
  return {
    'tree': domTree,
    'buttonExpand': buttonExpand
  };
}

/**
 * Create a DOM select box containing the node type
 * @return {HTML DOM} domType
 */ 
JSONEditor.Node.prototype._createDomType = function () {
  var domType = document.createElement('select');
  domType.className = 'jsoneditor-type';
  domType.title = 'Field type. When \"auto\" is selected, the type is automatically determined.';

  var options = ['array', 'auto', 'object', 'string'];
  for (var i in options) {
    if (options.hasOwnProperty(i)) {
      var optionDom = document.createElement('option');
      optionDom.value = options[i];
      optionDom.innerHTML = options[i];
      domType.appendChild(optionDom);
    }
  }
  domType.value = this.type;

  var me = this;
  domType.onchange = function (event) {
    var newType = domType.value;
    me._changeType(newType);
  }

  return domType;
}

/**
 * Create an append button. Returns undefined when the structure cannot
 * have an append button
 * @return {HTML DOM} buttonAppend or undefined when unapplicable
 */ 
JSONEditor.Node.prototype._createDomAppendButton = function () {
  if (this.type == 'object' || this.type == 'array') {
    var buttonAppend = document.createElement('button');
    buttonAppend.className = 'jsoneditor-append';
    buttonAppend.title = 'Append a field';
    
    var me = this;
    buttonAppend.onclick = function (event) {
      me._addChild();      
    }
    
    return buttonAppend;
  }
}


/**
 * Create a remove button. Returns undefined when the structure cannot
 * be removed
 * @return {HTML DOM} removeButton, or undefined when unapplicable
 */ 
JSONEditor.Node.prototype._createDomRemoveButton = function () {
  if (this.parent && (this.parent.type == 'array' || this.parent.type == 'object')) {
    var buttonRemove = document.createElement('button');
    buttonRemove.className = 'jsoneditor-remove';
    buttonRemove.title = 'Remove field (including all its childs)';
    
    var me = this;
    buttonRemove.onclick = function (event) {
      if (me.parent) {
        me.parent._removeChild(me);
      }
    }
    
    return buttonRemove;
  }
}

/**
 * get the type of a value
 * @param {any type} value
 * @return {String} type   Can be 'object', 'array', 'string', 'auto'
 */ 
JSONEditor.Node.prototype._getType = function(value) {
  if (value instanceof Array) {
    return 'array';
  }
  if (value instanceof Object) {
    return 'object';
  }  
  if (typeof(value) == 'string' && typeof(this._stringCast(value)) != 'string') {
    return 'string';
  }
  
  return 'auto';
}

/**
 * set the innertext of an HTML element (for example a div element)
 * @param {HTML DOM} element
 * @param {String} innerText
 */ 
JSONEditor.Node.prototype._setInnerText = function (element, innerText) {
  if (element.innerText) {
    element.innerText = innerText;
  }

  var innerHTML = innerText.replace(/\n/g, '<br>');
  element.innerHTML = innerHTML;
}

/**
 * cast contents of a string to the correct type. This can be a string, 
 * a number, a boolean, etc
 * @param {String} str
 * @return {String} type
 */ 
JSONEditor.Node.prototype._stringCast = function(str) {
  var lower = str.toLowerCase(),
    num = Number(str),       // will nicely fail with '123ab'
    float = parseFloat(str); // will nicely fail with '  '

  if (str == '') {
    return '';
  }
  else if (lower == 'null') {
    return null;
  }
  else if (lower == 'true') {
    return true;
  }
  else if (lower == 'false') {
    return false;
  }
  else if (!isNaN(num) && !isNaN(float)) {
    return num;
  }
  else {
    return str;
  }
}


/**
 * get the innertext of an HTML element (for example a div element)
 * @param {HTML DOM} element
 * @return {String} innerText
 */ 
JSONEditor.Node.prototype._getInnerText = function (element) {
  if (element.innerText) {
    return element.innerText;
  }
  
  // text node
  if (element.nodeValue) {
    return element.nodeValue;
  }
        
  // divs or other HTML elements
  if (element.hasChildNodes()) {
    var childNodes = element.childNodes;
    var innerText = "";

    for (var i = 0, iMax = childNodes.length; i < iMax; i++) {
      var child = childNodes[i];
      innerText += this._getInnerText(child);

      // TODO: check if this rule for adding \n is correct in all cases
      if (child.nodeName === 'DIV' && 
          innerText[innerText.length-1] !== '\n') {
        innerText += '\n';  
      }
    }

    return innerText;
  }

  // br
  if (element.nodeName === 'BR') {
    return '\n';
  }
  
  // unknown
  return '';
}

/**
 * remove the lastReturn
 * @param {String} text
 * @return {String} escaped text
 */ 
JSONEditor.Node.prototype._removeReturn = function (text) {
  if (text.charAt(text.length - 1) == '\n') {
    // remove last return character
    text = text.substring(0, text.length - 1);  
  }
  
  return text;
}

/**
 * Create main frame
 */ 
JSONEditor.prototype._createFrame = function () {
  // create the frame
  this.container.innerHTML = '';  
  this.frame = document.createElement('div');
  this.frame.className = 'jsoneditor-frame';
  this.container.appendChild(this.frame);
}

/**
 * Create main table
 */ 
JSONEditor.prototype._createTable = function () {
  this.table = document.createElement('table');
  this.table.className = 'jsoneditor-table';

  // create colgroup where the first two columns don't have a fixed 
  // width, and the edit columns do have a fixed width
  var col;
  this.colgroupContent = document.createElement('colgroup');
  col = document.createElement('col');
  this.colgroupContent.appendChild(col);
  col = document.createElement('col');
  this.colgroupContent.appendChild(col);
  col = document.createElement('col');
  col.width = "70px";
  this.colgroupContent.appendChild(col);
  col = document.createElement('col');
  col.width = "20px";
  this.colgroupContent.appendChild(col);
  col = document.createElement('col');
  col.width = "20px";
  this.colgroupContent.appendChild(col);
  this.table.appendChild(this.colgroupContent);


  this.tbody = document.createElement('tbody');
  this.table.appendChild(this.tbody);

  // create header column
  var tr, th;  
  tr = document.createElement('tr');
  th = document.createElement('th');
  th.className = 'jsoneditor-th'; 
  th.appendChild(document.createTextNode('Field'));
  tr.appendChild(th);
  th = document.createElement('th');
  th.className = 'jsoneditor-th'; 
  th.appendChild(document.createTextNode('Value'));
  tr.appendChild(th);
  th = document.createElement('th');
  th.className = 'jsoneditor-th'; 
  th.colSpan = 3;
  th.appendChild(document.createTextNode('Edit'));
  tr.appendChild(th);
  this.tbody.appendChild(tr);

  this.frame.appendChild(this.table);
}



/**
 * Get JSON object from editor
 * @return {Object} json
 */ 
JSONEditor.prototype.get = function () {
  if (this.node) {
    return this.node.getValue();
  }
  else {
    return {};
  }
}


JSONFormatter = function (container) {
  // check availability of JSON parser (not available in IE7 and older)
  if (!JSON) {
    throw 'Your browser does not support JSON. \n\n' +
      'Please use a decent, modern browser.';
  }
  
  this.container = container;

  this.width = container.clientWidth;
  this.height = container.clientHeight;

  this.frame = document.createElement('div');
  this.frame.className = "jsoneditor-frame";

  this.head = document.createElement('table');
  this.head.className = 'jsonformatter-table'; 
  var tbody = document.createElement('tbody');
  this.head.appendChild(tbody);
  this.frame.appendChild(this.head);

  var tr = document.createElement('tr');
  var th = document.createElement('th');
  th.className = 'jsoneditor-th'; 
  var buttonFormat = document.createElement('button');
  buttonFormat.innerHTML = 'Format';
  buttonFormat.title = 'Format JSON data, with proper indentation and line feeds';
  buttonFormat.className = 'jsoneditor-button';
  th.appendChild(buttonFormat);
  tr.appendChild(th);
  tbody.appendChild(tr);

  var buttonMinify = document.createElement('button');
  buttonMinify.innerHTML = 'Minify';
  buttonMinify.title = 'Minify JSON data, remove all whitespaces';
  buttonMinify.className = 'jsoneditor-button';
  th.appendChild(buttonMinify);
  tr.appendChild(th);
  tbody.appendChild(tr);

  this.textarea = document.createElement('textarea');
  this.textarea.className = "jsonformatter-textarea";
  this.frame.appendChild(this.textarea);

  var formatter = this;
  var textarea = this.textarea;
  var onChange = function () {
    formatter._checkChange();
  };
  /* TODO: register onchange
  this.textarea.onchange = onChange;
  this.textarea.onkeyup = onChange;
  this.textarea.oncut = onChange;
  this.textarea.oncopy = onChange;
  this.textarea.onpaste = onChange;
  this.textarea.onchange = function () {
    console.log('onchange');
  }
  this.textarea.ondomcharacterdatamodified = function () {
    console.log('DOMCharacterDataModified');
  }
  this.textarea.ondomattrmodified = function () {
    console.log('DOMAttrModified');
  }
  addEventListener(this.textarea, 'DOMAttrModified', function (event) {
    console.log('DOMAttrModified', event);
  });
  addEventListener(this.textarea, 'DOMCharacterDataModified', function (event) {
    console.log('DOMCharacterDataModified', event);
  });
  */

  buttonFormat.onclick = function () {
    textarea.value = JSONFormatter.format(JSON.parse(textarea.value));
  };
  buttonMinify.onclick = function () {
    textarea.value = JSON.stringify(JSON.parse(textarea.value));
  };
  
  this.container.appendChild(this.frame);
  
  // resize the elements
  this.redraw();
}

/**
 * Redraw the JSONFormatter, adjust size to fit container
 */ 
JSONFormatter.prototype.redraw = function() {
  var width = this.container.clientWidth;
  var height = this.container.clientHeight;
  var headHeight = this.head.clientHeight;

  this.textarea.style.height = (height - headHeight - 1) + 'px';
  this.textarea.style.width = '100%';
}

/**
 * Check if the contents are changed
 */ 
JSONFormatter.prototype._checkChange = function() {
  var content = this.textarea.value;
  
  if (content != this.lastContent) {
    this.lastContent = content;
    if (formatter.onChangeCallback) {
        formatter.onChangeCallback();
    }
  }
}

/**
 * Set json data in the formatter
 * @param {JSON} json
 */ 
JSONFormatter.prototype.set = function(json) {
  this.textarea.value = JSONFormatter.format(json);
}

/**
 * Get json data from the formatter
 * @return {JSON} json
 */ 
JSONFormatter.prototype.get = function() {
  return JSON.parse(this.textarea.value);
}

/**
 * Set a callback method for the onchange event
 * @return {function} callback
 */ 
/* TODO: setOnChangeCallback
JSONFormatter.prototype.setOnChangeCallback = function(callback) {
  this.onChangeCallback = callback;
  console.log(this.onChangeCallback, callback)
}
*/

/**
 * Format a json object as string
 * Example usage: 
 *   JSONFormatter.format({"field1": "bla", "somevalues": [1, 2, 3]});
 * 
 * @param {Object} json    A json object
 * @param {Number} level   Indentation level. Optional
 * @return {String} string Formatted string
 */
JSONFormatter.format = function (json, level) {
  var tab = '  ';  // indentation of 2 spaces (you can change this)
  var str = '';
  var level = level || 0;

  var indent = '';
  for(var i = 0; i < level; i++) {
    indent += tab;
  }

  if (json instanceof Array) {
    str += '[';
    var first = true;
    for (var i = 0, iMax = json.length; i < iMax; i++) {
      if (first) {
        first = false;
      }
      else {
        str += ',';
      }
      str += '\n' + indent + tab;
      str += JSONFormatter.format(json[i], level + 1);
    }
    str += '\n' + indent;
    str += ']';
  }
  else if (json instanceof Object) {
    str += '{';
    var first = true;
    for (var i in json) {
      if (json.hasOwnProperty(i)) {
        if (first) {
          first = false;
        }
        else {
          str += ',';
        }
        str += '\n' + indent + tab;
        //str += '"' + i + '": ';
        str += JSON.stringify(i) + ': ';
        str += JSONFormatter.format(json[i], level + 1);
      }
    }
    str += '\n' + indent;
    str += '}';
  }
  else if (typeof(json) == 'string') {
    return JSON.stringify(json);
  }
  else {
    return String(json);
  }
  
  return str;
}

